Android Aarti App

