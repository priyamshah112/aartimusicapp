package com.example.letsplay;

import android.media.MediaPlayer;

public class Global {
    public static MediaPlayer sMediaPlayer;
    public static MediaPlayer mMediaPlayer;
}
